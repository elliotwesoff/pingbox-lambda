var AWS = require('aws-sdk');
var dynamodb = new AWS.DynamoDB({ apiVersion: "2012-08-10" })
var s3 = new AWS.S3({apiVersion: '2006-03-01'});


exports.handler = function(event, context) {

    var srcBucket = event.Records[0].s3.bucket.name;
    var srcKey    = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, " "));  

    console.log("source bucket: " + srcBucket);
    console.log("source key: " + srcKey);

    s3.getObject({Bucket: srcBucket, Key: srcKey}, function(err, data) {
        if (err) {
            console.log("Error getting object " + srcKey + " from bucket " + srcBucket +
                    ". Make sure they exist and your bucket is in the same region as this function.");
            context.fail ("Error getting file: " + err)      
        } else {
            console.log('CONTENT TYPE:', data.ContentType);
            console.log('DATA:');

            //var jsonData = JSON.parse(data.Body.toString());

            //var pingDay = jsonData['ping_day'];
            //var  hostStats = jsonData['host_stats'];
            //var  packetLoss = jsonData['packet_loss'];
            //var  totalPings = jsonData['total_pings'];
            //var  totalFailedPings = jsonData['total_failed_pings'];

            //var dbItem = {
                //'TableName' : 'PingDay',
                //'Item' : {
                    //'M' : jsonData
                //}
            //};

            //dynamodb.putItem(dbItem, function(err, data) {
                //if (err) { 
                    //console.log(err, err.stack);
                //} else {
                    //console.log("success!!! " + data);
                //}
            //});



            context.succeed();
        }
    });
};
